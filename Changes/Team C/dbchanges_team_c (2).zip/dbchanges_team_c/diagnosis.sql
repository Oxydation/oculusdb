-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Erstellungszeit: 15. Mai 2015 um 08:38
-- Server Version: 5.6.21
-- PHP-Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: `oculus_c`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `diagnosis`
--

ALTER TABLE `diagnosis`
  DROP COLUMN `name`; 

ALTER TABLE `diagnosis`
  ADD COLUMN `description` varchar(512) DEFAULT NULL;

ALTER TABLE `diagnosis`
  ADD COLUMN `disease` varchar(36) DEFAULT NULL;

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `diagnosis`
--
ALTER TABLE `diagnosis`
 ADD KEY `fk_diagnosis_disease_idx` (`disease`);

--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `diagnosis`
--
ALTER TABLE `diagnosis`
ADD CONSTRAINT `fk_diagnosis_disease` FOREIGN KEY (`disease`) REFERENCES `disease` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
