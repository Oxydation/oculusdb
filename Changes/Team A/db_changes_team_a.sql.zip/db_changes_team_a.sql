DROP TABLE IF EXISTS workinghours;

CREATE TABLE workinghours (
  `id` varchar(36) NOT NULL DEFAULT 'UUID()',
  `employee` varchar(36) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_workinghours_employee_idx` (`employee`),
  CONSTRAINT `fk_workingday_employee_idx` FOREIGN KEY (`employee`) REFERENCES `employee` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

drop table if exists workingday;

CREATE TABLE `workingday` (
  `id` varchar(36) NOT NULL DEFAULT 'UUID()',
  `dayofweek` varchar(36) DEFAULT NULL,
  `start` datetime DEFAULT NULL,
  `end` datetime DEFAULT NULL,
  `workinghours` varchar(36) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_workingday_workinghours_idx` (`workinghours`),
  CONSTRAINT `fk_workingday_workinghours_idx` FOREIGN KEY (`workinghours`) REFERENCES `workinghours` (`id`) ON DELETE NO Action ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

